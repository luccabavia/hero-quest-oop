package map;

public class Element {

    private ElementType element;

    public Element(ElementType element) {
        this.element = element;
    }

    public void setElement(ElementType element) {
        this.element = element;
    }

    public ElementType getElement() {
        return element;
    }

    @Override
    public String toString() {

        switch (this.element) {

            case FLOOR:
                return "__";
            case WALL:
                return "XX";
            default:
                return "DD";
        }
    }
}
