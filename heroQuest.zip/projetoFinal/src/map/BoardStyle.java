package map;

public enum BoardStyle {
    STANDARD, RANDOM;
}
