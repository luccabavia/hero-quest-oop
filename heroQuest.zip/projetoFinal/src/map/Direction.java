package map;

public enum Direction {
    SOUTH, NORTH, WEST, EAST;
}
