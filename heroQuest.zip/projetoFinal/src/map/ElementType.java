package map;

public enum ElementType {
    WALL, FLOOR, DOOR;
}
