package map;

import characters.*;
import characters.monster.Monster;
import characters.monster.Skeleton;
import dice.Dice;
import io.Display;

import java.util.ArrayList;
import java.util.Arrays;

public class Board {

	private Object[][] board;
	private ArrayList<Monster> monsters;
	private Element wall = new Element(ElementType.WALL);
	private Element floor = new Element(ElementType.FLOOR);

	public void standardMap() {

		monsters = new ArrayList<>();

		Skeleton skeleton1 = new Skeleton(this);
		Skeleton skeleton2 = new Skeleton(this);
		Skeleton skeleton3 = new Skeleton(this);

		monsters.add(skeleton1);
		monsters.add(skeleton2);
		monsters.add(skeleton3);

		board = new Object[10][10];
		for (Object[] objects : board) {
			Arrays.fill(objects, floor);
		}

		board[1][1] = wall;
		board[1][2] = wall;
		board[1][3] = wall;
		board[1][4] = wall;
		board[2][4] = wall;
		board[3][4] = wall;
		board[4][4] = wall;
		board[5][5] = wall;

		positionSet(skeleton1,9,9);
		skeleton1.setPosition(9,9);
		positionSet(skeleton2,6,6);
		skeleton2.setPosition(6,6);
		positionSet(skeleton3,3,3);
		skeleton3.setPosition(3,3);
	}

	public void randomMap(){}

	public void drawBoard() {

		for (Object[] objects : board) {
			for (Object object : objects) {
				System.out.print(object.toString() + " ");
			}
			System.out.print("\n");
		}
	}

	public boolean moveCharacter(Characters c, int x, int y) {

		if (positionExists(x, y)) {
			if (positionIsEmpty(x, y)) {

				positionSetEmpty(c.getX(), c.getY());
				positionSet(c, x, y);

				return true;
			}
		}

		return false;
	}

	private boolean positionExists(int x, int y) {
		return x >= 0 && y >= 0 && x < board[0].length && y < board[1].length;
	}

	private boolean positionIsEmpty(int x, int y) {
		return board[x][y].equals(floor);
	}

	private void positionSetEmpty(int x, int y) {
		board[x][y] = this.floor;
	}

	private void positionSet(Characters character, int x, int y) {
		board[x][y] = character;
	}

	public void startPosition(Characters c) {
		c.setPosition(0,0);
		positionSet(c, 0,0);
	}

	public void moveMonster() {

		for (Monster m : monsters) {
			m.move(Dice.rollRedDice(m.getMovementDice()));
		}
	}
}
