package game;

import characters.Characters;
import dice.CombatDiceType;
import dice.Dice;

public class Combat {

    private int atk;
    private int def;

    public Combat(Characters attacker, Characters defender) {

        atk = Dice.rollCombatDice(attacker.getAttackDice(), CombatDiceType.SKULL);
        def = Dice.rollCombatDice(defender.getDefenseDice(), defender.getDefDiceType());
        defender.takeDamage(Math.max(0, (atk - def)));
    }
}
