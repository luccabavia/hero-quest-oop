package game;

import characters.Characters;
import characters.hero.*;
import characters.monster.Monster;
import characters.monster.Skeleton;
import dice.Dice;
import io.Keyboard;
import map.Board;
import io.Display;
import map.BoardStyle;

import java.util.ArrayList;

public class Game {

    private static boolean running;
    private ArrayList<Hero> heroes;
    private ArrayList<Monster> monsters;
    private Board board;
    private int steps;

    private ArrayList<Character> characters;

    public Game(BoardStyle boardStyle) {

        characters = new ArrayList<>();
        heroes = new ArrayList<>();
        monsters = new ArrayList<>();

        configure(boardStyle);
    }

    public void addPlayer(HeroType h) {

        Hero hero = selectHero(h);
        heroes.add(hero);
    }

    public void start() {

        running = true;
        board.startPosition(heroes.get(0));
        board.drawBoard();

        while (running) {
            move(heroes.get(0));

            board.moveMonster();
        }
    }

    public void configure(BoardStyle boardStyle){

        board = new Board();

        switch (boardStyle) {
            case STANDARD:
                board.standardMap();
                break;
            default:
                board.randomMap();
                break;
        }
    }

    private Hero selectHero(HeroType heroType) {

        switch (heroType) {
            case BARBARIAN:
                return new Barbarian(board);
            case DWARF:
                return new Dwarf(board);
            case WIZARD:
                return new Wizard(board);
            case ELF:
                return new Elf(board);
        }

        return null;
    }

    private void move(Hero h) {

        String command;
        do {

            Display.print("Press r to roll the Dice");
            command = Keyboard.getInput();

        } while (!command.equalsIgnoreCase("r"));

        steps = Dice.rollRedDice(h.getMovementDice());

        while (steps > 0) {

            Display.print("You have "+ (steps) + " moves left.");
            String action = Keyboard.getInput();

            if (action.equalsIgnoreCase("w")) {
                if (h.moveNorth()) steps--;
            } else if (action.equalsIgnoreCase("s")) {
                if (h.moveSouth()) steps--;
            } else if (action.equalsIgnoreCase("a")) {
                if (h.moveWest())  steps--;
            } else if (action.equalsIgnoreCase("d")) {
                if (h.moveEast())  steps--;
            } else {

                Display.print("press w to move in North direction!");
                Display.print("press s to move in South direction!");
                Display.print("press a to move in West direction!");
                Display.print("press d to move in East direction!");

            }

            board.drawBoard();
        }
    }
}
