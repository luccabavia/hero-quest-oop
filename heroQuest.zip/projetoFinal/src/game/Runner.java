package game;

import characters.hero.HeroType;
import map.BoardStyle;

public class Runner {

    public static void main(String[] args) {

        Game g = new Game(BoardStyle.STANDARD);
        g.addPlayer(HeroType.DUMMY);
        g.start();
    }
}
