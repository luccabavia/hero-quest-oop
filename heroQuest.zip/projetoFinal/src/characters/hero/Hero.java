package characters.hero;

import dice.CombatDiceType;
import map.Board;

import characters.Characters;

public class Hero extends Characters {

    private String name;
    private int armor;
    private int[] hands = new int[2]; // 0 = Livre, 1 = Ocupada
    private Object[] bag;
    
    public Hero(Board board, int attackDice, int defenseDice, int movementDice, int healthPoints, int mindPoints, String sprite) {
        super(board, attackDice, defenseDice, movementDice, healthPoints, mindPoints, sprite);
        board.startPosition(this);
        this.defDiceType = CombatDiceType.WHITE_SHIELD;
    }

    /*
    Search for items in positions directly around the Hero, counter clockwise
     */

    /*
    public void searchForItems() {

        int[][] adjacentPositions = new int[][] {
                {X, Y + 1},       // East
                {X - 1, Y + 1},   // Northeast
                { X - 1,  Y},       // North
                { X - 1,  Y - 1},   // Northwest
                { X,  Y - 1},       // West
                { X + 1,  Y - 1},   // Southwest
                { X + 1,  Y},       // South
                { X + 1,  Y + 1}    // Southeast
        };

        for (int[] i: adjacentPositions) {
            if (Map.hasItem(i)) {
                this.collectItem(i[0], i[1]);
                break;
            }
        }

    }
     */
    /*
    Collect item and add to the bag
     */
    public void collectItem(int x, int y) {

    }

    @Override
    public void attack() {

    }

    @Override
    public void defend() {

    }

    @Override
    protected void takeDamage() {

    }

    @Override
    protected void castSpell() {

    }
}


