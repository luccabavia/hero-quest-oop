package characters.hero;

public enum HeroType {
    BARBARIAN, DWARF, ELF, WIZARD, DUMMY;
}
