package characters.hero;

import characters.Weapon;
import map.Board;

public class Dwarf extends Hero{

    public Dwarf(Board board) {
        super(board, 2, 2, 2, 7, 3, "DD");
        this.weapon = new Weapon();
    }
}
