package characters.hero;

import characters.Weapon;
import map.Board;

public class Wizard extends Hero{

    public Wizard(Board board) {
        super(board, 1, 2, 2, 4, 6, "WW");
        this.weapon = new Weapon();
    }
}
