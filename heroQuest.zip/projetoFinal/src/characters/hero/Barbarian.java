package characters.hero;

import characters.Weapon;
import map.Board;

public class Barbarian extends Hero {

    public Barbarian(Board board) {
        super(board, 3, 2, 2, 8, 2, "BB");
        this.weapon = new Weapon();
    }
}
