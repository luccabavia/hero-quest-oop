package characters.hero;

import characters.Weapon;
import map.Board;

public class Elf extends Hero {
    public Elf(Board board) {
        super(board, 2, 2, 2, 6, 4, "EE");
        this.weapon = new Weapon();
    }
}
