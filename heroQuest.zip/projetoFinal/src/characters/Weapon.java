package characters;

public class Weapon {

}
