package characters.monster;

import map.Board;
import java.util.Random;

public class Skeleton extends Monster {

    public Skeleton(Board board) {
        super(board, 2, "SK");
    }

    @Override
    public void move(int steps) {

        Random random;

        while (steps > 0) {

            random = new Random();
            int number = random.nextInt(4) + 1;

            switch (number) {
                case 1:
                    if(moveNorth()) steps--;
                    break;
                case 2:
                    if(moveSouth()) steps--;
                    break;
                case 3:
                    if(moveEast()) steps--;
                    break;
                default:
                    if(moveWest()) steps--;
                    break;
            }
            attack();
        }
    }

    @Override
    public void attack() {}
}
