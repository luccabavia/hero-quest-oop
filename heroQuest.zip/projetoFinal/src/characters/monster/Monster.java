package characters.monster;

import dice.CombatDiceType;
import map.Board;
import characters.Characters;

public abstract class Monster extends Characters {

    Monster(Board board, int movementDice, String sprite) {
        super(board, movementDice, sprite);
        this.defDiceType = CombatDiceType.BLACK_SHIELD;
    }

    public abstract void move(int steps);
}
