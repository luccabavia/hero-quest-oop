package characters.monster;

import map.Board;

public class Goblin extends Monster {


    Goblin(Board board, int movementDice, String sprite) {
        super(board, movementDice, sprite);
    }

    @Override
    public void move(int steps) {

        
    }

    private void findRoute() {


    }
}
