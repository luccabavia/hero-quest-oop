package characters.monster;

public class MageSkeleton extends Monster{
}
