package characters;

import dice.CombatDiceType;
import map.Board;

public abstract class Characters {

    protected Board board;
    protected int x;
    protected int y;
    protected int attackDice;
    protected int defenseDice;
    protected CombatDiceType defDiceType;
    protected int movementDice;
    protected int healthPoints;
    protected int mindPoints;
    protected String sprite;
    protected Weapon weapon;
//    private Spell[] spells;

    public Characters(Board board, int attackDice, int defenseDice, int movementDice, int healthPoints, int mindPoints, String sprite) {
        this.board = board;
        this.attackDice = attackDice;
        this.defenseDice = defenseDice;
        this.movementDice = movementDice;
        this.healthPoints = healthPoints;
        this.mindPoints = mindPoints;
        this.sprite = sprite;
    }

    public CombatDiceType getDefDiceType() {
        return this.defDiceType;
    }
    public int getMovementDice(){
        return movementDice;
    }

    public void takeDamage(int damage){
        this.healthPoints -= damage;
    }

    protected void castSpell(){};

    protected String getSprite() {
        return this.sprite;
    }

    public String getStatus() {
        String s = String.format("Positon: (%d, %d), Attack dice: %d, " +
                "Defense dice: %d, Body points: %d, Mind points: %d",
                this.x, this.y, this.attackDice, this.defenseDice,
                this.mindPoints, this.mindPoints);
        return s;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    // Movement methods. Returns true if the character change its position. False otherwise.
    public boolean moveNorth() {
        if (board.moveCharacter(this, x - 1, y)) {
            x--;
            return true;
        }
        return false;
    }

    public boolean moveWest() {
        if (board.moveCharacter(this, x, y - 1)) {
            y--;
            return true;
        }
        return false;
    }

    public boolean moveSouth() {
        if (board.moveCharacter(this, x + 1, y)) {
            x++;
            return true;
        }
        return false;
    }

    public boolean moveEast() {
        if (board.moveCharacter(this, x, y + 1)) {
            y++;
            return true;
        }
        return false;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return this.sprite;
    }

    public int getAttackDice() {
        return this.attackDice;
    }

    public int getDefenseDice() {
        return defenseDice;
    }
}
