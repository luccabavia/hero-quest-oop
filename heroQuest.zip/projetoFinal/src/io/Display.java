package io;

public class Display {

    public static void print(String string) {
        System.out.println(string);
    }

}
