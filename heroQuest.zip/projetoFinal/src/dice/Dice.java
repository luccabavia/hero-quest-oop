package dice;

import java.util.Random;

public class Dice {

    // Returns the sum of the values of the number of dices rolled.
    public static int rollRedDice(int nDices) {

        Random random;
        int value = 0;

        for (int i = 0; i < nDices; i++) {
            random = new Random();
            value += random.nextInt(6) + 1;
        }

        return value;
    }

    // Returns a combat mark among skull, white shield and black shield.
    public static int rollCombatDice(int nDices, CombatDiceType  action) {

        int skull = 0;
        int whiteShield = 0;
        int blackShield = 0;

        Random random = new Random();

        for (int i = 0; i < nDices; i++) {

            int number = random.nextInt(6) + 1;
            if (number == 1 || number == 3 || number == 5) skull++;
            else if (number == 2 || number == 4) whiteShield++;
            else blackShield++;
        }

        switch (action) {
            case BLACK_SHIELD:
                return blackShield;
            case WHITE_SHIELD:
                return whiteShield;
            default:
                return skull;
        }
    }
}