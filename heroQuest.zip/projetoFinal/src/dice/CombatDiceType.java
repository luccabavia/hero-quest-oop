package dice;

public enum CombatDiceType {
    SKULL, BLACK_SHIELD, WHITE_SHIELD;
}
