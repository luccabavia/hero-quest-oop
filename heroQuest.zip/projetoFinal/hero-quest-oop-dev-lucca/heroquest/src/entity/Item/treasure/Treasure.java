package entity.Item.treasure;

public abstract class Treasure {

    private int value;

    public Treasure(int value) {

    }

    public int getValue() {
        return this.value;
    }

}
