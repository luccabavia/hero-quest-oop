package entity.Item.treasure;

public class Diamond extends Treasure {

    public Diamond() {
        super(50);
    }

}
