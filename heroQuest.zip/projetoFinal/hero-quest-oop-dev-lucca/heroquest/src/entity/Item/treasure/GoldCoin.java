package entity.Item.treasure;

public class GoldCoin extends Treasure {

    public GoldCoin() {
        super(1);
    }

}
