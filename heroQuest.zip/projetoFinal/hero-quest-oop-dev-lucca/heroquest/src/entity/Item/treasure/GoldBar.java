package entity.Item.treasure;

public class GoldBar extends Treasure {

    public GoldBar() {
        super(10);
    }
}
