package entity.Item.equipment.spell;

import entity.character.Character;

public class Teleport extends Spell {

    public Teleport() {
        super(1);
    }

    @Override
    public void castSpell(Character target) {
        //target.getVisi
    }
}
