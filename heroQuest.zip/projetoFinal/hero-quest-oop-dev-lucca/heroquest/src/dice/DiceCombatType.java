package dice;

public enum DiceCombatType {
    SKULL, BLACK_SHIELD, WHITE_SHIELD;
}
